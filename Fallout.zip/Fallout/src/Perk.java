import java.awt.image.BufferedImage;

public class Perk extends Stat {

    public Perk(String a, String b) {
        super(a,b," ");
        value = 0;
    }
}
