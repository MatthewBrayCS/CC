import java.awt.image.BufferedImage;

public class SecAtt extends Stat{

    public SecAtt(String a, String b, String c) {
        super(a,b,c);
        value = 0;
    }
}
