import java.awt.image.BufferedImage;

public class SPECIAL extends Stat {

    public SPECIAL(String a, String b) {
        super(a,b," ");
        value = 5;
    }
}
