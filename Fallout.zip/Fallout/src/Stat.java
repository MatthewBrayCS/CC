import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public abstract class Stat {

    public String name;
    public String desc;
    public BufferedImage pic;
    public int value;
    public String formula = "";

    public Stat(String a, String b, String c) {
        name = a;
        desc = b;
        try {
            pic = ImageIO.read(new File("Resources/" + name + ".png"));
        } catch (IOException e) {
        }
        formula = c;
    }
}
