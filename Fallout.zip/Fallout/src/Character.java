public class Character {

    String name;
    int age;
    boolean male;
    SPECIAL[] spec = new SPECIAL[7];
    SecAtt[] att = new SecAtt[13];
    Skill[] skills = new Skill[18];
    Perk[] perks = new Perk[69];

    public Character() {
        spec[0] = new SPECIAL("Strength","Raw physical strength. A high Strength is good for physical characters");
        spec[1] = new SPECIAL("Perception","The ability to see, hear, taste and notice unusual things. A high Perception is important for a sharpshooter");
        spec[2] = new SPECIAL("Endurance","Stamina and physical toughness. A character with a high Endurance will survive where others may not");
        spec[3] = new SPECIAL("Charisma","A combination of appearance and charm. A high Charisma is important for characters that want to influence people with words");
        spec[4] = new SPECIAL("Intelligence","Knowledge, wisdom and the ability to think quickly. A high Intelligence is important for any character");
        spec[5] = new SPECIAL("Agility","Coordination and the ability to move well. A high Agility is important for any active character");
        spec[6] = new SPECIAL("Luck","Fate. Karma. An extremely high or low Luck will affect the character - somehow. Events and situations will be changed by how lucky (or unlucky) your character is");

        att[0] = new SecAtt("Hit Points","How much damage your character can take before dying. If you reach 0 HP or less, you are dead", "15 + Strength + (2 x Endurance");
        att[1] = new SecAtt("Armour Class","How good your character is at avoiding being hit in combat", "Agility + Armour equipped");
        att[2] = new SecAtt("Action Points","The amount of actions your character can take during a combat turn", "5 + (Agility / 2)");
        att[3] = new SecAtt("Carry Weight","The maximum amount of equipment your character can carry, in pounds", "25 + (Strength x 25)");
        att[4] = new SecAtt("Melee Damage","Amount of bonus damage in hand-to-hand combat", "Strength - 5, minimum 1");
        att[5] = new SecAtt("Damage Resistance","Any damage taken is reduced by this amount. Damage Resistance can be increased by wearing armor", "Armour equipped");
        att[6] = new SecAtt("Poison Resistance","Reduces any poison damage by this amount", "Endurance x 5");
        att[7] = new SecAtt("Radiation Resistance","The amount of radiation you are exposed to is reduced by this percentage. Radiation Resistance can be modified by the type of armor worn, and anti-radiation chems", "Endurance x 2");
        att[8] = new SecAtt("Sequence","Determines how soon in a combat turn your character can react", "Perception x 2");
        att[9] = new SecAtt("Healing Rate","At the end of each day, your character will heal 1 HP for each point of Healing Rate. When you rest, you heal every six hours", "Endurance / 3 minimum 1");
        att[10] = new SecAtt("Skill Rate","The number of skill points you will be able to allocate to skills, each time you gain a level", "5 (Intelligence * 2)");
        att[11] = new SecAtt("Perk Rate","The amount of levels the character will have to gain in order to gain a perk. (lower is better)", "3");
        att[12] = new SecAtt("Critical Chance","The chance to cause a critical hit in combat is increased by this amount", "Luck");

        skills[0] = new Skill("Small Guns","The use, care and general knowledge of small firearms - pistols, SMGs and rifles", "35 + Agility");
        skills[1] = new Skill("Big Guns","The operation and maintenance of really big guns - miniguns, rocket launchers, flamethrowers and such", "10 + Agility");
        skills[2] = new Skill("Energy Weapons","The care and feeding of energy-based weapons. How to arm and operate weapons that use laser or plasma technology", "10 + Agility");
        skills[3] = new Skill("Unarmed","A combination of martial arts, boxing and other hand-to-hand martial arts. Combat with your hands and feet", "65 + ((Agility + Strength) / 2)");
        skills[4] = new Skill("Melee Weapons","Using non-ranged weapons in hand-to-hand or melee combat - knives, sledgehammers, spears, clubs and so on", "55 + ((Strength + Agility) /2)");
        skills[5] = new Skill("Throwing","The skill of muscle-propelled ranged weapons, such as throwing knives, spears and grenades", "40 + Agility");
        skills[6] = new Skill("First Aid","General healing skill. Used to heal small cuts, abrasions and other minor ills. In game terms, the use of first aid can heal more hit points over time than just rest", "30 + ((Perception + Intelligence) / 2)");
        skills[7] = new Skill("Doctor","The healing of major wounds and crippled limbs. Without this skill, it will take a much longer period of time to restore crippled limbs to use", "15 + ((Perception + Intelligence) / 2)");
        skills[8] = new Skill("Sneak","Quiet movement, and the ability to remain unnoticed. If successful, you will be much harder to locate. You cannot run and sneak at the same time", "25 + Agility");
        skills[9] = new Skill("Lockpick","The skill of opening locks without the proper key. The use of lockpicks or electronic lockpicks will greatly enhance this skill", "20 + ((Perception + Agility) / 2)");
        skills[10] = new Skill("Steal","The ability to make things of others your own. Can be used to steal from people or places", "20 + Agility");
        skills[11] = new Skill("Traps","The finding and removal of traps. Also the setting of explosives for demolition purposes", "20 + ((Perception + Agility) / 2)");
        skills[12] = new Skill("Science","Covers a variety of high-technology skills, such as computers, biology, physics, and geology", "25 + (2 x Intelligence)");
        skills[13] = new Skill("Repair","The practical application of the Science skill, for fixing of broken equipment, machinery and electronics", "20 + Intelligence");
        skills[14] = new Skill("Speech","The ability to communicate in a practical and efficient manner. The skill of convincing others that your position is correct. The ability to lie and not get caught", "25 + (2 x Charisma)");
        skills[15] = new Skill("Barter","Trading and trade-related tasks. The ability to get better prices for items you sell, and lower prices for items you buy", "20 + (2 x Charisma)");
        skills[16] = new Skill("Gambling","The knowledge and practical skills related to wagering. The skill at cards, dice and other games", "20 + (3 x Luck)");
        skills[17] = new Skill("Outdoorsman","Practical knowledge of the outdoors, and the ability to live off the land. The knowledge of plants and animals", "5 + ((Intelligence + Endurance) / 2)");

        perks[0] = new Perk("Fast Metabolism","Your metabolic rate is twice normal. This means that you are much less resistant to radiation and poison, but your body heals faster");
        perks[1] = new Perk("Bruiser","A little slower, but a little bigger. You may not hit as often, but they will feel it when you do! Your total action points are lowered, but your Strength is increased");
        perks[2] = new Perk("Small Frame","You are not quite as big as other people, but that never slowed you down. You can't carry as much, but you are more agile");
        perks[3] = new Perk("One Hander","One of your hands is very dominant. You excel with single-handed weapons, but two-handed weapons cause a problem");
        perks[4] = new Perk("Finesse","Your attacks show a lot of finesse. You don't do as much damage, but you cause more critical hits");
        perks[5] = new Perk("Kamikaze","By not paying attention to any threats, you can act a lot faster in a turn. This lowers your Armor Class to just what you are wearing, but you sequence much faster in a combat turn");
        perks[6] = new Perk("Heavy Handed","You swing harder, not better. Your attacks are very brutal, but lack finesse. You rarely cause a good critical hit, but you always do more melee damage");
        perks[7] = new Perk("Fast Shot","You don't have time to aim for a targeted attack, because you attack faster than normal people. It costs you one less action point for guns and thrown weapons");
        perks[8] = new Perk("Bloody Mess","By some strange twist of fate, people around you die violently. You always see the worst way a person can die");
        perks[9] = new Perk("Jinxed","The good thing is that everyone around you has more critical failures in combat, the bad thing is - so do you");
        perks[10] = new Perk("Good Natured","You studied less-combative skills as you were growing up. Your combat skills start at a lower level, but other skills are substantially improved.");
        perks[11] = new Perk("Chem Reliant","You are more easily addicted to chems. Your chance to be addicted by chem use is twice normal, but you recover faster from their ill effects");
        perks[12] = new Perk("Chem Resistant","Chems only affect you half as long as normal, but your chance to be addicted is also only 50% of normal");
        perks[13] = new Perk("Night Person","As a night-time person, you are more awake when the sun goes down. Your Intelligence and Perception are improved at night, but dulled during the day");
        perks[14] = new Perk("Skilled","Since you spend more time improving your skills than a normal person, you start with better skills levels. The tradeoff is that you do not gain as many extra abilities. You will gain a perk every four levels");
        perks[15] = new Perk("Gifted","You have more innate abilities than most, so you have not spent as much time honing your skills");
    }

    public boolean modspecial(int x, boolean up) {
        if (up) {
            spec[x].value++;
            if (spec[x].value == 10) {
                return true;
            } else {
                return false;
            }
        } else {
            spec[x].value--;
            if (spec[x].value == 1) {
                return true;
            } else {
                return false;
            }
        }
    }

    public void updatevalues() {
        att[0].value = 15 + spec[0].value + (2 * spec[2].value);
        att[1].value = spec[5].value;
        att[2].value = 5 + (spec[5].value / 2);
        att[3].value = 25 + (spec[0].value * 25);
        att[4].value = spec[0].value - 5;
        if (att[4].value < 1) {
            att[4].value = 1;
        }
        att[5].value = 0;
        att[6].value = spec[2].value * 5;
        att[7].value = spec[2].value * 2;
        att[8].value = 2 * spec[1].value;
        att[9].value = (spec[2].value + 2) / 3;
        att[10].value = (spec[4].value * 2) + 5;
        att[11].value = 3;
        att[12].value = spec[6].value;

        skills[0].value = 35 + spec[5].value;
        skills[1].value = 10 + spec[5].value;
        skills[2].value = 10 + spec[5].value;
        skills[3].value = 65 + ((spec[0].value + spec[5].value) / 2);
        skills[4].value = 55 + ((spec[0].value + spec[5].value) / 2);
        skills[5].value = 40 + spec[5].value;
        skills[6].value = 30 + (spec[1].value + spec[4].value);
        skills[7].value = 15 + (spec[1].value + spec[4].value);
        skills[8].value = 25 + spec[5].value;
        skills[9].value = 20 + (spec[1].value + spec[5].value);
        skills[10].value = 20 + spec[5].value;
        skills[11].value = (int)(20 + (0.5 * spec[1].value) + (0.5 * spec[5].value));
        skills[12].value = 25 + (2 * spec[4].value);
        skills[13].value = 20 + spec[4].value;
        skills[14].value = 25 + (2 * spec[3].value);
        skills[15].value = 20 + (2 * spec[4].value);
        skills[16].value = 20 + (3 * spec[6].value);
        skills[17].value = (int)(5 + (0.5 * spec[2].value) + (0.5 * spec[4].value));

        for (int i = 0; i < 18; i++) {
            if (skills[i].tagged) {
                skills[i].value += 15;
            }
        }

        for (int i = 0; i < 16; i++) {
            if (perks[i].value != 0) {
                dotrait(i);
            }
        }
    }

    private void dotrait(int x) {
        switch (x) {
            case 0:
                att[9].value += 2;
                att[6].value = 0;
                att[7].value = 0;
                break;
            case 1:
                att[2].value -= 2;
                break;
            case 2:
                att[3].value = 25 + (15 * spec[0].value);
                break;
            case 4:
                att[12].value += 10;
                break;
            case 5:
                att[8].value += 5;
                att[1].value = 0;
                break;
            case 6:
                att[4].value += 4;
                break;
            case 10:
                skills[6].value += 15;
                skills[7].value += 15;
                skills[14].value += 15;
                skills[15].value += 15;
                skills[0].value -= 10;
                skills[1].value -= 10;
                skills[2].value -= 10;
                skills[3].value -= 10;
                skills[4].value -= 10;
                skills[5].value -= 10;
                break;
            case 14:
                for (int i = 0; i < 16; i++) {
                    skills[i].value += 10;
                }
                att[11].value = 4;
                break;
            case 15:
                for (int i = 0; i < 16; i++) {
                    skills[i].value -= 10;
                }
        }
    }
}
