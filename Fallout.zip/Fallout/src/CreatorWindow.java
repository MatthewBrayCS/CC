import javafx.scene.input.KeyCode;
import org.jdesktop.swingx.JXLabel;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.sql.SQLOutput;

public class CreatorWindow extends JFrame{

    private JTextField namebox;
    private JLabel age;
    private JTextField agebox;
    private JButton gender;

    private JPanel specbox;
    private JLabel speclab;
    private JLabel[] specnames;
    private JLabel[] specnum;
    private JLabel[] specdesc;
    private JButton[] specbutt;
    int specleft = 5;
    private JLabel specrem;

    private JPanel secbox;
    private JLabel[] seclab;
    private JLabel[] secnum;

    private JPanel tagbox;
    private JPanel skillbox;
    private JLabel skilllab;
    private JLabel[] skillnames;
    private JLabel[] skillnum;
    private JCheckBox[] tags;
    private JLabel tagnum;
    int tagleft = 3;

    private JPanel traitbox;
    private JPanel tnbox;
    private JLabel traitlabel;
    private JLabel[] traitnames;
    private JCheckBox[] traits;
    int traitleft = 2;

    private JPanel infobox;
    private JLabel infolab;
    private JLabel formulalab;
    private JPanel descbox;
    public JXLabel desclab;

    final int namelimit = 15;

    Character player;

    BufferedImage currentimg = null;

    public KeyListener namelistener = new KeyListener() {
        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {
            if (namebox.getText().length() > 14) {
                namebox.setText(namebox.getText().substring(0, Math.min(namelimit, namebox.getText().length())));
            }
            player.name = namebox.getText();
        }
    };

    public MouseListener nameclicker = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {
            if (namebox.getText().length() == 20) {
                namebox.setText("");
            }
        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    };

    public KeyListener agelistener = new KeyListener() {
        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {
            if (e.getKeyCode() != KeyEvent.VK_ENTER && e.getKeyCode() != KeyEvent.VK_BACK_SPACE) {
                if (agebox.getText().length() > 1) {
                    agebox.setText(agebox.getText().substring(0, Math.min(2, agebox.getText().length())));
                }
                try {
                    player.age = Integer.parseInt(agebox.getText());
                    if ((agebox.getText().length() == 2) && player.age < 16 || player.age > 35) {
                        player.age = 0;
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException err) {
                    JOptionPane.showMessageDialog(null, "Age must be an integer between 16 and 35 (inclusively)", "Error", JOptionPane.ERROR_MESSAGE);
                    agebox.setText("");
                }
            }
        }
    };

    public FocusListener agefocus = new FocusListener() {
        @Override
        public void focusGained(FocusEvent e) {

        }

        @Override
        public void focusLost(FocusEvent e) {
            if (player.age < 16 || player.age > 35) {
                JOptionPane.showMessageDialog(null,"Please enter a valid age", "Error", JOptionPane.ERROR_MESSAGE);
                agebox.grabFocus();
            }
        }
    };

    public ActionListener genderlistener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (player.male) {
                gender.setText("♀");
                gender.setForeground(Color.pink);
                player.male = false;
            } else {
                gender.setText("♂");
                gender.setForeground(Color.blue);
                player.male = true;
            }
        }
    };

    public ActionListener speclistener = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            int i = 0;
            boolean found = false;
            while (!found && i < 14) {
                if (specbutt[i] == e.getSource()) {
                    found = true;
                } else {
                    i++;
                }
            }
            if (i < 7) {
                if (player.modspecial(i, true)) {
                    specbutt[i].setEnabled(false);
                }
                specbutt[i+7].setEnabled(true);
                specleft--;
                if (specleft < 1) {
                    for (int x = 0; x < 7; x++) {
                        specbutt[x].setEnabled(false);
                    }
                }
            } else {
               if (player.modspecial(i - 7, false)) {
                   specbutt[i].setEnabled(false);
               }
               specbutt[i-7].setEnabled(true);
               specleft++;
            }
            player.updatevalues();
            updatelabels();
        }
    };

    public ItemListener taglistener = new ItemListener() {
        @Override
        public void itemStateChanged(ItemEvent e) {
            int x = 0;
            for (int i = 0; i < 18; i++) {
                if (e.getSource() == tags[i]) {
                    x = i;
                }
            }
            if (e.getStateChange() == 1) {
                player.skills[x].tagged = true;
                tagleft--;
                if (tagleft < 1) {
                    for (int i = 0; i < 18; i++) {
                        if (!tags[i].isSelected()) {
                            tags[i].setEnabled(false);
                        }
                    }
                }
            } else {
                player.skills[x].tagged = false;
                tagleft++;
                for (int i = 0; i < 18; i++) {
                    tags[i].setEnabled(true);
                }
            }
            player.updatevalues();
            updatelabels();
        }
    } ;

    public ItemListener traitlistener = new ItemListener() {
        @Override
        public void itemStateChanged(ItemEvent e) {
            int x = 0;
            for (int i = 0; i < 16; i++) {
                if (e.getSource() == traits[i]) {
                    x = i;
                }
            }
            if (e.getStateChange() == 1) {
                if (x == 15) {
                    specleft += 7;
                }
                if (x == 1) {
                    player.spec[0].value += 2;
                }
                if (x == 2) {
                    player.spec[5].value += 1;
                }
                player.perks[x].value = 1;
                traitleft--;
                if (traitleft < 1) {
                    for (int i = 0; i < 16; i++) {
                        if (!traits[i].isSelected()) {
                            traits[i].setEnabled(false);
                        }
                    }
                }
            } else {
                if (x == 1) {
                    player.spec[0].value -= 2;
                }
                if (x == 2) {
                    player.spec[5].value -= 1;
                }
                if (x == 15) {
                    specleft -= 7;
                    if (specleft == 0) {
                        for (int i = 0; i < 7; i++) {
                            specbutt[i].setEnabled(false);
                        }
                    }
                }
                player.perks[x].value = 0;
                traitleft++;
                for (int i = 0; i < 16; i++) {
                    traits[i].setEnabled(true);
                }
            }
            player.updatevalues();
            updatelabels();
        }
    };

    public MouseListener imagelistener = new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent e) {
            for (int i = 0; i < 7; i++) {
                if (e.getSource() == specnames[i]) {
                    showinfo(player.spec[i]);
                }
            }
            for (int i = 0; i < 13; i++) {
                if (e.getSource() == seclab[i]) {
                    showinfo(player.att[i]);
                }
            }
            for (int i = 0; i < 18; i++) {
                if (e.getSource() == skillnames[i]) {
                    showinfo(player.skills[i]);
                }
            }
            for (int i = 0; i < 16; i++) {
                if (e.getSource() == traitnames[i]) {
                    showinfo(player.perks[i]);
                }
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    };

    public CreatorWindow() {
        player = new Character();
        this.setLayout(null);

        BufferedImage pic = null;
        try {
            pic = ImageIO.read(new File("Resources/Back.jpg"));
        } catch (IOException e) {
        }
        final BufferedImage back = pic;
        JPanel pane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(back, 0, 0,1920,1080, null);
            }
        };
        pane.setLayout(null);
        this.add(pane);
        pane.setBounds(0,0,1920,1080);
        pane.setVisible(true);

        namebox = new JTextField("Enter character name");
        namebox.addKeyListener(namelistener);
        namebox.addMouseListener(nameclicker);
        namebox.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        pane.add(namebox);
        namebox.setBounds(30, 30, 180, 30);
        namebox.setVisible(true);

        age = new JLabel("Age:");
        pane.add(age);
        age.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        age.setBounds(260,30,50,30);
        age.setForeground(Color.yellow);
        age.setVisible(true);

        agebox = new JTextField();
        agebox.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        agebox.addKeyListener(agelistener);
        agebox.addFocusListener(agefocus);
        pane.add(agebox);
        agebox.setBounds(300, 30, 30, 30);
        agebox.setVisible(true);

        player.male = true;
        gender = new JButton("♂");
        gender.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        gender.addActionListener(genderlistener);
        pane.add(gender);
        gender.setForeground(Color.blue);
        gender.setBounds(380, 30, 50, 30);
        gender.setVisible(true);

        specbox = new JPanel(null);
        specbox.setBorder(BorderFactory.createLineBorder(Color.black, 4));
        pane.add(specbox,BorderLayout.CENTER);
        specbox.setOpaque(false);
        specbox.setBounds(30, 90, 800, 450);
        specbox.setVisible(true);

        speclab = new JLabel("S.P.E.C.I.A.L");
        speclab.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        speclab.setForeground(Color.yellow);
        specbox.add(speclab);
        speclab.setBounds(10, 5, 150, 30);
        speclab.setVisible(true);

        specnames = new JLabel[7];
        int x = 10;
        int y = 30;
        for (int i = 0; i < 7; i++) {
            specnames[i] = new JLabel(player.spec[i].name + ":");
            specnames[i].setHorizontalAlignment(SwingConstants.RIGHT);
            specnames[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            specnames[i].setForeground(Color.yellow);
            specnames[i].addMouseListener(imagelistener);
            specbox.add(specnames[i]);
            specnames[i].setBounds(x,y,100,30);
            specnames[i].setVisible(true);
            y += 55;
        }

        specnum = new JLabel[7];
        x = 140;
        y = 30;
        for (int i = 0; i < 7; i++) {
            specnum[i] = new JLabel("5",SwingConstants.CENTER);
            specnum[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            specnum[i].setForeground(Color.green);
            specnum[i].setOpaque(true);
            specnum[i].setBackground(Color.black);
            specbox.add(specnum[i]);
            specnum[i].setBounds(x,y,30,30);
            specnum[i].setVisible(true);
            y += 55;
        }

        specdesc = new JLabel[7];
        x = 200;
        y = 30;
        for (int i = 0; i < 7; i++) {
            specdesc[i] = new JLabel("Average",SwingConstants.CENTER);
            specdesc[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            specdesc[i].setForeground(Color.green);
            specdesc[i].setOpaque(true);
            specdesc[i].setBackground(Color.black);
            specbox.add(specdesc[i]);
            specdesc[i].setBounds(x,y,100,30);
            specdesc[i].setVisible(true);
            y += 55;
        }

        specbutt = new JButton[14];
        x = 330;
        y = 30;
        for (int i = 0; i < 14; i++) {
            if (i < 7) {
                specbutt[i] = new JButton("↑");
            } else {
                specbutt[i] = new JButton("↓");
            }
            specbutt[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            specbutt[i].addActionListener(speclistener);
            specbox.add(specbutt[i]);
            specbutt[i].setBounds(x,y,80,30);
            specbutt[i].setVisible(true);
            y += 55;
            if (i == 6) {
                y = 30;
                x += 110;
            }
        }

        secbox = new JPanel(null);
        secbox.setBackground(Color.black);
        specbox.add(secbox);
        secbox.setBounds(550, 25, 240, 400);

        seclab = new JLabel[13];
        x = 5;
        y = 5;
        for (int i = 0; i < 13; i++) {
            seclab[i] = new JLabel(player.att[i].name + ":", SwingConstants.RIGHT);
            seclab[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            seclab[i].setForeground(Color.green);
            seclab[i].addMouseListener(imagelistener);
            secbox.add(seclab[i]);
            seclab[i].setBounds(x,y,180,25);
            seclab[i].setVisible(true);
            y+= 30;
        }

        secnum = new JLabel[13];
        x = 190;
        y = 5;
        for (int i = 0; i < 13; i++) {
            secnum[i] = new JLabel("", SwingConstants.LEFT);
            secnum[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            secnum[i].setForeground(Color.green);
            secbox.add(secnum[i]);
            secnum[i].setBounds(x,y,180,25);
            secnum[i].setVisible(true);
            y+= 30;
        }

        specrem = new JLabel("Points Remaining: 5");
        specrem.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        specrem.setForeground(Color.yellow);
        specbox.add(specrem);
        specrem.setBounds(30,400,180,25);
        specrem.setVisible(true);

        tagbox = new JPanel(null);
        tagbox.setBorder(BorderFactory.createLineBorder(Color.black, 4));
        tagbox.setOpaque(false);
        pane.add(tagbox,BorderLayout.CENTER);
        tagbox.setBounds(860, 90, 800,610);
        tagbox.setVisible(true);

        skilllab = new JLabel("Skills:");
        skilllab.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        skilllab.setForeground(Color.yellow);
        tagbox.add(skilllab);
        skilllab.setBounds(10,5,80,25);
        skilllab.setVisible(true);

        skillbox = new JPanel(null);
        skillbox.setBackground(Color.black);
        tagbox.add(skillbox);
        skillbox.setBounds(50, 30, 725, 550);

        skillnames = new JLabel[18];
        x = 5;
        y = 5;
        for (int i = 0; i < 18; i++) {
            skillnames[i] = new JLabel(player.skills[i].name + ":");
            skillnames[i].setHorizontalAlignment(SwingConstants.RIGHT);
            skillnames[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            skillnames[i].addMouseListener(imagelistener);
            skillnames[i].setForeground(Color.green);
            skillbox.add(skillnames[i]);
            skillnames[i].setBounds(x,y,150,25);
            skillnames[i].setVisible(true);
            y += 30;
        }

        skillnum = new JLabel[18];
        x = 670;
        y = 5;
        for (int i = 0; i < 18; i++) {
            skillnum[i] = new JLabel("100%");
            skillnum[i].setHorizontalAlignment(SwingConstants.RIGHT);
            skillnum[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            skillnum[i].setForeground(Color.green);
            skillbox.add(skillnum[i]);
            skillnum[i].setBounds(x,y,50,25);
            skillnum[i].setVisible(true);
            y += 30;
        }

        tags = new JCheckBox[18];
        x = 15;
        y = 40;
        for (int i = 0; i < 18; i++) {
            tags[i] = new JCheckBox();
            tags[i].setHorizontalAlignment(SwingConstants.CENTER);
            tags[i].addItemListener(taglistener);
            tagbox.add(tags[i]);
            tags[i].setBounds(x,y,15,15);
            tags[i].setVisible(true);
            y += 30;
        }

        tagnum = new JLabel("Tag! Skills remaining: 3");
        tagnum.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        tagnum.setForeground(Color.yellow);
        tagbox.add(tagnum);
        tagnum.setBounds(5,580,250,25);
        tagnum.setVisible(true);

        traitbox = new JPanel(null);
        traitbox.setBorder(BorderFactory.createLineBorder(Color.black, 4));
        traitbox.setOpaque(false);
        pane.add(traitbox,BorderLayout.CENTER);
        traitbox.setBounds(30, 560, 800, 440);
        traitbox.setVisible(true);

        tnbox = new JPanel(null);
        tnbox = new JPanel(null);
        tnbox.setBackground(Color.black);
        traitbox.add(tnbox);
        tnbox.setBounds(50, 30, 700, 400);

        traitlabel = new JLabel("Optional Traits:");
        traitlabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        traitlabel.setForeground(Color.yellow);
        traitbox.add(traitlabel);
        traitlabel.setBounds(10,5,250,25);
        traitlabel.setVisible(true);

        traitnames = new JLabel[16];
        x = 5;
        y = 15;
        for (int i = 0; i < 16; i++) {
            traitnames[i] = new JLabel(player.perks[i].name);
            traitnames[i].setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
            traitnames[i].setForeground(Color.green);
            traitnames[i].addMouseListener(imagelistener);
            if (i < 8) {
                traitnames[i].setHorizontalAlignment(SwingConstants.LEFT);
            } else {
                traitnames[i].setHorizontalAlignment(SwingConstants.RIGHT);
            }
            tnbox.add(traitnames[i]);
            traitnames[i].setBounds(x,y,140,25);
            traitnames[i].setVisible(true);
            y += 50;
            if (i == 7) {
                x = 555;
                y = 15;
            }
        }

        traits = new JCheckBox[16];
        x = 15;
        y = 50;
        for (int i = 0; i < 16; i++) {
            traits[i] = new JCheckBox();
            traits[i].setHorizontalAlignment(SwingConstants.CENTER);
            traits[i].addItemListener(traitlistener);
            traitbox.add(traits[i]);
            traits[i].setBounds(x,y,15,15);
            traits[i].setVisible(true);
            y += 50;
            if (i == 7) {
                y = 50;
                x = 770;
            }
        }

        infobox = new JPanel(null);
        infobox.setBorder(BorderFactory.createLineBorder(Color.black, 4));
        infobox.setOpaque(false);
        pane.add(infobox,BorderLayout.CENTER);
        infobox.setBounds(860, 730, 800,270);
        infobox.setVisible(true);

        descbox= new JPanel(null);
        descbox = new JPanel(null);
        descbox.setBackground(Color.black);
        infobox.add(descbox);
        descbox.setBounds(30, 30, 340, 230);

        infolab = new JLabel("Radiation Resistance");
        infolab.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        infolab.setForeground(Color.yellow);
        infobox.add(infolab);
        infolab.setBounds(30,5,250,25);
        infolab.setVisible(true);

        formulalab = new JLabel("35 + ((Perception + Intelligence) / 2)");
        formulalab.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        formulalab.setForeground(Color.yellow);
        infobox.add(formulalab);
        formulalab.setBounds(400,5,300,25);
        formulalab.setVisible(true);

        desclab = new JXLabel("Since you spend more time improving your skills than a normal person, you start with better skills levels. The tradeoff is that you do not gain as many extra abilities. You will gain a perk every four levels");
        desclab.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 18));
        desclab.setForeground(Color.green);
        descbox.add(desclab);
        desclab.setLineWrap(true);
        desclab.setVerticalAlignment(SwingConstants.TOP);
        desclab.setBounds(5,5,330,230);
        desclab.setVisible(true);

        player.updatevalues();
        updatelabels();

    }


    public void updatelabels() {
        for (int i = 0; i < 7; i++) {
            specnum[i].setText(String.valueOf(player.spec[i].value));
            if (specleft > 0 && player.spec[i].value < 10) {
                specbutt[i].setEnabled(true);
            }
            if (player.spec[i].value > 1) {
                specbutt[i + 7].setEnabled(true);
            }
            switch (player.spec[i].value) {
                case 1:
                    specdesc[i].setText("V. Bad");
                    break;
                case 2:
                    specdesc[i].setText("Bad");
                    break;
                case 3:
                    specdesc[i].setText("Poor");
                    break;
                case 4:
                    specdesc[i].setText("Fair");
                    break;
                case 5:
                    specdesc[i].setText("Average");
                    break;
                case 6:
                    specdesc[i].setText("Good");
                    break;
                case 7:
                    specdesc[i].setText("V. Good");
                    break;
                case 8:
                    specdesc[i].setText("Great");
                    break;
                case 9:
                    specdesc[i].setText("Excellent");
                    break;
                case 10:
                    specdesc[i].setText("Heroic");
                    break;
            }
            specrem.setText("Points Remaining: " + specleft);
        }

        for (int i = 0; i < 13; i++) {
            if (i == 5 || i == 7 || i == 6 || i == 12) {
                secnum[i].setText(String.valueOf(player.att[i].value) + "%");
            } else {
                secnum[i].setText(String.valueOf(player.att[i].value));
            }
        }

        for (int i = 0; i < 18; i++) {
            skillnum[i].setText(player.skills[i].value + "%");
        }
        tagnum.setText("Tag! Skills remaining: " + tagleft);

        if (player.perks[1].value == 1) {
            if (player.spec[0].value < 3) {
                traits[1].setEnabled(false);
            } else {
                traits[1].setEnabled(true);
            }
        }
        if (player.perks[1].value == 0) {
            if (player.spec[0].value > 8) {
                traits[1].setEnabled(false);
            } else {
                traits[1].setEnabled(true);
            }
        }

        if (player.perks[2].value == 1) {
            if (player.spec[5].value < 2) {
                traits[2].setEnabled(false);
            } else {
                traits[2].setEnabled(true);
            }
        }
        if (player.perks[2].value == 0) {
            if (player.spec[5].value > 9) {
                traits[2].setEnabled(false);
            } else {
                traits[2].setEnabled(true);
            }
        }

        if (player.perks[15].value == 1) {
            if (specleft < 7) {
                traits[15].setEnabled(false);
            } else {
                traits[15].setEnabled(true);
            }
        }
    }

    public void showinfo(Stat x) {
        infolab.setText(x.name);
        desclab.setText(x.desc);
        formulalab.setText(x.formula);

        final BufferedImage img = x.pic;
        JPanel imgbox = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(img, 0, 0,this.getWidth(),this.getHeight(),null);
            }
        };
        imgbox.setLayout(null);
        infobox.add(imgbox);
        imgbox.setBounds(400,30,320,230);
        imgbox.setVisible(true);
    }

    public static void main(String[] args) {
        CreatorWindow frame = new CreatorWindow();
        frame.setDefaultCloseOperation(3);
        frame.setBounds(0,0,1920,1080);
        frame.setVisible(true);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    }
}
