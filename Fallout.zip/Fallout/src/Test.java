import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Test {

    public static void main(String[] args) {
        BufferedImage img = null;
        JFrame frame = new JFrame();
        frame.setLayout(null);
        frame.setBounds(0, 0, 1920, 1080);
        frame.setVisible(true);
        String name = "pic";
        try {
            img = ImageIO.read(new File("Resources/" + name + ".png"));
        } catch (IOException e) {

        }
        final BufferedImage pic = img;
        JPanel pane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(pic, 0, 0,1080,720, null);
            }
        };
        frame.add(pane);
        pane.setBounds(0,0,1080,720);
        Perk bla = new Perk("","");
        System.out.println(3/3);

    }
}
