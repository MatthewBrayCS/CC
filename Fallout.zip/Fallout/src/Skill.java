import java.awt.image.BufferedImage;

public class Skill extends Stat{
    boolean tagged = false;

    public Skill(String a, String b, String c) {
        super(a,b,c);
        value = 0;
    }
}
